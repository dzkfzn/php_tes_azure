#UTS NO2

tgl=`date +%d%m%Y`

echo "Menu Program"
echo "a. Scan file"
echo "b. History Scanning"
echo -n "PIlihan: "

read ch
case $ch in
a)
	echo "Masukkan nama file: "
	read cek
		if [ -d $cek ]
		then
			hasil="tidak memiliki ekstensi"
		elif [ -f $cek]
		then
			hasil="memiliki ekstensi"
		else
			hasil="tidak memiliki extensi"
		fi
		echo `echo $ceik-$hasil-$tgl >> gg.txt`
	;;
esac
