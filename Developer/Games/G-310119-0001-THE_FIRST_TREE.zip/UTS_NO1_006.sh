#UTS NO1

fUTS="UTS1.txt"
date=`date +%d%m%Y`
time=`date +%d%m%Y-%H:%M:%S`


`mkdir BACKUP/$date`
`cp -R $fUTS BACKUP/$date/`



if [ -d BACKUP/$date ]
then
	notif="Berhasil"
else
	notif="Gagal"
fi

size= `du -hs BACKUP/$date/`

echo `echo $date-$size-$status | cut -f1 -d` ` >> BACKUP/.backup.log`
